/*
  main.cpp - Main loop for Arduino sketches
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "Arduino.h"






HardwareSerial Serial(0);
HardwareSerial Serial1(1);



/**********************************************************************
* 功能描述：查找栈增长方向
* 输入参数：无
* 输出参数：无
* 返 回 值：无
* 其它说明：无
* 修改日期        版本号      修改人              修改内容
* ---------------------------------------------------------------
* 20151202        V1.0     Zhou Zhaoxiong          创建
***********************************************************************/
void FindStackDirection(void)
{
    uint8_t  iStackAddr        = 0;        // 用于获取栈地址
    static uint8_t *pStackAddr = NULL;     // 用于存放第一个iStackAddr的地址 

    if (pStackAddr == NULL)              // 第一次进入
    {                          
        pStackAddr = &iStackAddr;        // 保存iStackAddr的地址
        FindStackDirection();            // 递归 
    }
    else                                 // 第二次进入 
    {  
        if (&iStackAddr > pStackAddr)        // 第二次iStackDirection的地址大于第一次iStackDirection, 那么说明栈增长方向是向上的
        {   
            printf("Stack grows up!\n");
        }
        else if (&iStackAddr < pStackAddr)   // 第二次iStackDirection的地址小于第一次iStackDirection, 那么说明栈增长方向是向下的
        {  
            printf("Stack grows down!\n");
        }
        else
        {
            printf("Bad stack!\n");
        }
    }
} 



int main( void )
{
	System_init();
	TIMER1_init();
	setup();
	
	for (;;)
	{
		loop();
	}

	return 0;
}
