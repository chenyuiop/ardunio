/**
 *******************************************************************************
 * @file    sw_uart.h
 * @author  Yancy
 * @version V1.0.0
 * @date    10-10-2013
 * @brief   sw uart driver header file
 * @ʹ��ע�����
 * 1) ����뽫SWUART������ض��򵽱�׼����˿�(ʹ��DBG��ӡ)����Ҫ���ú���
 *    EnableSwUartAsFuart(TRUE)����ʹ�ܡ�
 * 2) ������Cache��ʼ��֮����������������ݡ��ڱ�׼SDK�У�����Cache��ʼ��������
 *    ��OSStartKernel�У�������OSStartKernel֮����������������ݻ��ӡ��Ϣ��
 *******************************************************************************
 * @attention
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, MVSILICON SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
 * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2013 MVSilicon </center></h2>
 */

/**
 * @addtogroup MVUtils
 * @{
 * @defgroup sw_uart sw_uart
 * @{
 */

#ifndef __SW_UART_H__
#define __SW_UART_H__

#ifdef __cplusplus
extern "C" {
#endif//__cplusplus


#include "type.h"
#include "gpio.h"

/* GPIO bank selection */
#define  SWUART_GPIO_PORT_A    GPIO_A_IN
#define  SWUART_GPIO_PORT_B    GPIO_B_IN
#define  SWUART_GPIO_PORT_C    GPIO_C_IN

/**
 * @brief  Redirect SWUART to standard output(for example, DBG)
 * @param  EnableFlag: 0: not redirect, 1: redirect
 * @return None.
 */
void EnableSwUartAsFuart(bool EnableFlag);

/**
 * @brief  Init specified IO as software uart's TX.
 *         The BaudRate is valid in DPLL 96M,if you use RC48M its true value is an half of BaudRate.
 *         Any other divided frequency is the same with last example.
 * @param  PortIndex: select which gpio bank to use
 *     @arg  SWUART_GPIO_PORT_A
 *     @arg  SWUART_GPIO_PORT_B
 *     @arg  SWUART_GPIO_PORT_C
 * @param  PinIndex:  0 ~ 31, select which gpio io to use.
 *         for example, if PortIndex = SWUART_GPIO_PORT_A, PinIndex = 10,
 *         GPIO_A10 is used as software uart's TX.
 * @param  BaudRate, can be 115200, 57600 or 38400
 * @return None.
 */
void SwUartTxInit(uint8_t PortIndex, uint8_t PinIndex, uint32_t BaudRate);

/**
 * @brief  Deinit uart TX to default gpio.
 * @param  PortIndex: select which gpio bank to use
 *     @arg  SWUART_GPIO_PORT_A
 *     @arg  SWUART_GPIO_PORT_B
 *     @arg  SWUART_GPIO_PORT_C
 * @param  PinIndex:  0 ~ 31, select which gpio io to deinit.
 * @return None.
 */
void SwUartTxDeinit(uint8_t PortIndex, uint8_t PinIndex);


/**
 * @brief  Send data from buffer
 * @param  Buf: Buffer address
 * @param  BufLen: Length of bytes to be send
 * @return None.
 * @note   This function can only be used after OSStartKernel() is called
 */
void SwUartSend(uint8_t* Buf, uint32_t BufLen);


#ifdef  __cplusplus
}
#endif//__cplusplus

#endif	//__SW_UART_H__
