#ifndef		__P20_VERSION_H__
#define		__P20_VERSION_H__

#define SDK_VER_CHIPID  ".byte 0x14 \n\n"		//0xB8       //MV SDK chip  id
#define SDK_VER_MAJOR	".byte 0 \n\n"			//0xB9       //MV SDK major version
#define SDK_VER_MINOR	".byte 1 \n\n"			//0xBA       //MV SDK minor version
#define SDK_VER_USER	".byte 3 \n\n"			//0xBB       //   version







#endif
