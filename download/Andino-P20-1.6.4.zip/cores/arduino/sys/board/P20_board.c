/*!
 **************************************************************************************************
 *  \copyright
 *    Copyright (c) 2012-2013 M-Square Comm.
 *    This software is the proprietary information of M2C Comm.
 *    All Right Reserved.
 **************************************************************************************************
 *  \file m2c8001_board.c
 *  \brief M2C8001 init function
 *  $Date: 2014-04-14
 *
 *
 * ------------------------------------------------------------------------------------------------
 */


/***********************************************************************************************
*   INCLUDES
***********************************************************************************************
#include "m2c8001_int.h"
#include "m2c8001_gpio.h"
#include "m2c8001_timer.h"
#include "m2c8001_sys.h"
#include "m2c8001_pmu.h"*/

#include <string.h>
#include <nds32_intrinsic.h>
#include "type.h"
#include "irqn.h"
#include "cache_tcm.h"
#include "timeout.h"
#include "debug.h"
#include "delay.h"
#include "timeout.h"
#include "watchdog.h"
#include "gpio.h"
#include "clk.h"
#include "uarts_interface.h"
#include "spi_flash.h"
#include "adc.h"



/***********************************************************************************************
*   GLOBAL VARIABLES
************************************************************************************************/
extern inline void GIE_ENABLE(void);

/***********************************************************************************************
*   LOCAL FUNCTIONS
************************************************************************************************/
static void IsrInit(void)
{
    //extern void initIntr();
    //extern void GIE_ENABLE();
    /* Initialize interrupt */
   // initIntr();
   // GIE_ENABLE();
   // GPIO_IsrInit();
   // TIMER_IsrInit(TIMER1);
   
   
}



static void ADC_Init(void)
{
	

	
	ADC_Clr();
	Clock_ModuleEnable(SARADC_CLK_EN);
	Clock_MclkConfig(0, 0);
	Clock_SarADCClkSelect(1);//0: mclk_clk_30m;1: sadc_clk_30m
	Clock_SarADCClkDivSet(11);//15 = 15M,11=20M,7 = 30M
	ADC_ModeSet(0);   //1:AC;    0:Dc
	ADC_VrefSet(1);//1:VDDA; 0:2.4*VGA
	ADC_DCClkDivSet(0); //0:no div
	//ADC_DCChannelSet(3);
	ADC_Enable();



#define     REG_SARADC_ANA_CTRL            (*(volatile unsigned long *) 0x4002802C)
#define     REG_PGA_CTRL                   (*(volatile unsigned long *) 0x40028030)

	REG_SARADC_ANA_CTRL |= 0x4000000;

	REG_SARADC_ANA_CTRL &= ~0xE00;
	REG_SARADC_ANA_CTRL |= 0xC00;

	REG_PGA_CTRL |= 0x1;
	REG_PGA_CTRL &= ~0x10;
   
}


/***********************************************************************************************
*   GLOBAL FUNCTIONS
************************************************************************************************/



void InitZiArea(void)
{
	/* Use compiler builtin and memset */
	#define MEMSET(s, c, n) __builtin_memset ((s), (c), (n))

	extern char _end;
	extern char __bss_start;
	int size;

	/* Clear bss section */
	size = &_end - &__bss_start;
	MEMSET(&__bss_start, 0, size);
	return;
}
/***********************************************************************************************
@brief:System Init function of SOC m2c8001
***********************************************************************************************/
void System_init(void)
{
	WDG_Disable();
	CacheTcmInitFast(PHYMEM_16KBPM0 /*cache*/, PHYMEM_16KBPM1/*tcm r0*/, 0/*tcm r0 offset*/, 4/*tcm r0 size*/, PHYMEM_NONE/*tcm r1*/, 0/*tcm r1 offset*/, 0/*tcm r1 size*/);

	GPIO_RegOneBitClear(GPIO_B_PU, GPIOB30);
	GPIO_RegOneBitSet(GPIO_B_PD, GPIOB30);
	GPIO_RegOneBitClear(GPIO_B_PU, GPIOB31);
	GPIO_RegOneBitSet(GPIO_B_PD, GPIOB31);
	Clock_Config(1, 12000000);
	Clock_PllLock(480000);
	Clock_SysClkSelect(PLL_CLK_MODE);
	Clock_UARTClkSelect(1);
	
	InitZiArea();
	SpiFlashInit(80000000, MODE_4BIT, 0, 1);
	 
	 
	GPIO_UartTxIoConfig(0, 1);//C2
	GPIO_UartRxIoConfig(0, 1);//C3
	//UARTS_Init(0, 115200, 8, 0, 1);
	DbgUartInit(0, 115200, 8, 0, 1);
	//UART0_Send("-------------------------------------------------------\n",sizeof("-------------------------------------------------------\n")-1);
	//UART0_Send("P20 Ardunio System_init()\n",sizeof("P20 Ardunio System_init()\n")-1);	
	//UART0_Send("-------------------------------------------------------\n",sizeof("-------------------------------------------------------\n")-1);
	 
    IsrInit();
	ADC_Init();
	
	GIE_ENABLE();
}


