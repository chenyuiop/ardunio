#include "Arduino.h"

#ifdef __cplusplus
 extern "C" {
#endif

#define SARADC_WAIT_US    (20)
#define SARADC_DELAY_US    (5)
#define SARADC_SAMPLE_CNT  (5)



#define AIN_PORT(X)	    	     GPIO_A_##X

const uint32_t Tab_Ain_Pin[] = 
{
	GPIOA3,
	GPIOA4,
	GPIOA5,
	GPIOA6,
	GPIOA9,
};

const uint32_t Tab_Ain_Channel[] = 
{
	ADC_CHANNEL_GPIOA3,
	ADC_CHANNEL_GPIOA4,
	ADC_CHANNEL_GPIOA5,
	ADC_CHANNEL_GPIOA6,
	ADC_CHANNEL_GPIOA9,
};

void AGPIO_ENA(uint32_t pin)
{
	
	uint32_t  AIN_PIN = Tab_Ain_Pin[pin];
	
	GPIO_RegOneBitSet(AIN_PORT(PD), AIN_PIN);	//PU=0,PD=0:上拉无下拉
	GPIO_RegOneBitClear(AIN_PORT(PU), AIN_PIN);
	GPIO_RegOneBitClear(AIN_PORT(PULLDOWN1), AIN_PIN);//关下拉电流值
	GPIO_RegOneBitClear(AIN_PORT(PULLDOWN2), AIN_PIN);
	GPIO_RegOneBitSet(AIN_PORT(IE), AIN_PIN);//输入
	GPIO_RegOneBitClear(AIN_PORT(OE), AIN_PIN);//输出
	
}




uint32_t ResolutionRead = 10;
uint32_t PWMBit = 0;

#define MAX(a,b) ((a>b)?a:b)
#define DIFF(a,b) ((a>b)?(a-b):(b-a))
#define AVGSAMPLE 0
int analogRead(uint8_t pin)
{
    int avg=0,max=0,val[SARADC_SAMPLE_CNT];
    int i=0;
	
#if AVGSAMPLE
    int j=0,cnt=0;
#endif

    if (pin >= 5)
        return 0;

    AGPIO_ENA(pin);

    delayMicroseconds(SARADC_DELAY_US);

    for(i=0;i<SARADC_SAMPLE_CNT;i++) //sample adc servel times and average
    {

        //delayMicroseconds(SARADC_WAIT_US);
        val[i] = ADC_DCChannelDataGet(Tab_Ain_Channel[pin]);
        max =MAX(max,val[i]);
#if AVGSAMPLE
        if(i==(SARADC_SAMPLE_CNT-1))
        {
            for(j=0;j<SARADC_SAMPLE_CNT;j++)
            {
                if(val[j]>(max*95/100))
                {
                    avg+=val[j];
                    cnt++;
                }
            }
        }
#endif
    }
#if AVGSAMPLE
    avg/=cnt;
#else
    avg=max;
#endif
    //sarADC_DeInit();
    //AGPIO_DIS_SAR_Func(pin);
    //AGPIO_DIS(pin);

    //HW max resolution is actually 12 bits
    if(ResolutionRead)
    {
        //#define ADJUST_FACTOR (1.82)
        //HW max resolution is actually 10 bits
        //avg *= (1<<ResolutionRead)*ADJUST_FACTOR/1024;
		avg = avg *(1<<ResolutionRead)>>12;
    }

    return avg;
}

void analogReadResolution(uint8_t bit)
{

    if(bit == 0)
        return;

    if (bit >= 16) //HW max resolution is actually 10 bits
        bit = 16;

    ResolutionRead = bit;
}







//const char Tab_PinTimer[] = {0,0,TIMER3,TIMER4,TIMER5,TIMER6,TIMER7,TIMER8};
const TIMER_INDEX Tab_PinTimer[] = {TIMER3,TIMER3,TIMER3,TIMER4,TIMER5,TIMER6,TIMER7,TIMER8};


 void PWM_GpioConfigDeInit(TIMER_INDEX TimerIdx)
{
	if(TimerIdx == TIMER3)
	{
		PWM_GpioConfig(TIMER3_PWM1_A2_B22_A30_C7, 0, PWM_IO_MODE_NONE);
	}

	if(TimerIdx == TIMER4)
	{
		PWM_GpioConfig(TIMER4_PWM1_A3_B23_A31_C8, 0, PWM_IO_MODE_NONE);
	}
}

 void PWM_GpioConfigInit(TIMER_INDEX TimerIdx)
{
	if(TimerIdx == TIMER3)
	{
		PWM_GpioConfig(TIMER3_PWM1_A2_B22_A30_C7, 0, PWM_IO_MODE_OUT);
		//printf("PWM Init OUTPUT: A2\n");
	}

	if(TimerIdx == TIMER4)
	{
		PWM_GpioConfig(TIMER4_PWM1_A3_B23_A31_C8, 0, PWM_IO_MODE_OUT);
		//DBG("PWM Init OUTPUT: A3\n");
	}
	
	if(TimerIdx == TIMER5)
	{
		PWM_GpioConfig(TIMER5_PWM1_P_A16, 0, PWM_IO_MODE_OUT);
		//DBG("PWM Init OUTPUT: A16\n");
	}
	if(TimerIdx == TIMER6)
	{
		PWM_GpioConfig(TIMER6_PWM1_P_B6, 0, PWM_IO_MODE_OUT);
		//DBG("PWM Init OUTPUT: B6\n");
	}
	if(TimerIdx == TIMER7)
	{
		PWM_GpioConfig(TIMER7_PWM1_P_C4, 0, PWM_IO_MODE_OUT);
		//DBG("PWM Init OUTPUT: C4\n");
	}
	if(TimerIdx == TIMER8)
	{
		PWM_GpioConfig(TIMER8_PWM1_P_B9, 0, PWM_IO_MODE_OUT);
		//DBG("PWM Init OUTPUT: B9\n");
	}
}

/*************************************************************************/

void analogWrite(uint8_t pin, int val)
{
    //uint8_t PwmDiv = 0;
    uint32_t Duty = 0;
    //uint32_t period = 0XFFFF;
    uint32_t frequency = 1000; //make 1KHz frequency
	TIMER_INDEX    timer;
    PWM_StructInit	pwmParam;

    if((pin != 2)&&(pin != 3)&&(pin != 8)&&(pin != 9))  //only A4 & A5 & D8 &D9 can be set PWM( use PWM0,PWM1)
        return;

   // PwmDiv = 0x0;

   // period = 32768/frequency; //how many T

   // if(val == 0)
   //     Duty = 0;
   // else if(val == 255)
   //     Duty = period;
   // else
   //     Duty = (period*val)/255;

    if(PWMBit)
    {
        //Duty &= PWMBit;
        //period &= PWMBit;		
		if(val == 0)
			Duty = 0;
		else if(val == ((1<<PWMBit) - 1))
			Duty = 0XFFFF;
		else
		{
			Duty = (val << 16)>>PWMBit;		
			if(val > ((1<<PWMBit) - 1))
			{
				Duty = 0XFFFF;
			}
		}
		
		
		
        PWMBit = 0;
    }
	else
	{
		if(val == 0)
			Duty = 0;
		else if(val == 255)
			Duty = 0XFFFF;
		else
		{
			Duty = (val << 16)>>8;//默认8bit，最大255表示100%占空比
			if(val > 255)
			{
				Duty = 0XFFFF;
			}
		}
			
			
	}
  // Duty = 0XFFFF;
 //   PWM_CLK_EN(pin);
 //   MTF_PWM_ENA(pin);
 //   PWM_Set_Clk_Src(pin);
 //   PWM_Config_Setting(pin,Duty,period-1,PwmDiv);
 //   PWM_ENA(pin);
 
 
    timer = Tab_PinTimer[pin];
	
	PWM_GpioConfigInit(timer);

	pwmParam.CounterMode		= PWM_COUNTER_MODE_UP;
	pwmParam.OutputType			= PWM_OUTPUT_SINGLE_1;
	pwmParam.DMAReqEnable		= PWM_REQ_INTERRUPT_MODE;
	pwmParam.FreqDiv			= 120000000/frequency;
	pwmParam.Duty[0]			= Duty; //50%
	pwmParam.OutEnable[0]		= OUTP_ENABLE_AND_OUTN_DISABLE;
	PWM_Config(timer, PWM1, &pwmParam);
	PWM_DutyConfigIQ16(timer, PWM1, Duty);
	PWM_Enable(timer);
}

void analogReference(uint8_t mode)
{
    //The feature is not supported.
}

void analogWriteResolution(uint8_t bit)
{
    //int duty_maskbit = 0;
   // int i = 0;

    if(bit == 0)
        return;

    if (bit >= 12) //max resolution is 10 bits
        bit = 12;

//    for(i=0;i<bit;i++)
//        duty_maskbit |= (0x1 << i);

    PWMBit = bit;//duty_maskbit;
}

#ifdef __cplusplus
}
#endif
