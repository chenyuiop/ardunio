/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif

volatile uint32_t us_time = 0;
volatile uint32_t ms_time = 0;

extern volatile uint32_t gSysTick;

uint32_t GetSysTime_us(void)
{

    volatile uint32_t ms, cycle_cnt;
#define     REG_TIMER1_CNT                 (*(volatile unsigned long *) 0x4002A014)
#define     REG_TIMER2_CNT                 (*(volatile unsigned long *) 0x4002A814)

    do
    {
        ms = gSysTick;
        cycle_cnt = REG_TIMER2_CNT;//
    } while (ms != gSysTick);//两次ms计数值不一样，重读一次

    return (ms * 1000) + (1000 - cycle_cnt);
}



void TIMER1_init(void)
{
	SysTickInit();
}

uint32_t us_ticker_read(void) {
	#define     REG_TIMER2_CNT                 (*(volatile unsigned long *) 0x4002A814)
    uint32_t tm1_cntr;
   /* uint32_t us_time_unit;
    us_time_unit = 0;//SYS_GetAPBClockFreq() / 1000000;
    tm1_cntr = TIMER->TM1COUNTER / us_time_unit;
    return tm1_cntr;*/
	tm1_cntr = (1000 - REG_TIMER2_CNT);
	return tm1_cntr;
}

void delay(uint32_t ms) {
    volatile uint32_t start;
    start = millis();
    while ((millis() - start) < ms);
}

uint32_t millis( void ) {
  /*  uint32_t ms_time_tmp;
    ms_time_tmp = (uint32_t) us_ticker_read() / 1000;
    return ms_time + ms_time_tmp;*/
	
	return gSysTick;
}

uint32_t micros( void ) {
  /*  uint32_t us_time_tmp;
    us_time_tmp = (uint32_t) us_ticker_read();
    return us_time + us_time_tmp;*/
	return GetSysTime_us();
}

void delayMicroseconds(uint32_t usec) {
    volatile uint32_t start;
    start = micros();
    while ((micros() - start) < usec);
}
#ifdef __cplusplus
}
#endif
