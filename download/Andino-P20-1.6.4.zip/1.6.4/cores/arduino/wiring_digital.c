/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "Arduino.h"


uint32_t pin_dmux[14]={GPIOB0,GPIOB1,GPIOB2,GPIOB3,GPIOB4,GPIOB5,GPIOB6,GPIOB7,GPIOB8,GPIOB9,GPIOB10,GPIOB11,GPIOB12,GPIOB13};

void pinMode( int pin_m, uint8_t mode )
{
    uint32_t pin = pin_dmux[pin_m];

	 if (mode == INPUT)
    {
        GPIO_RegOneBitSet(GPIO_B_IE, pin);
        GPIO_RegOneBitClear(GPIO_B_OE, pin);
		GPIO_RegOneBitSet(GPIO_B_PU, pin);//b'10 = no pull-up, no pull-down
	    GPIO_RegOneBitClear(GPIO_B_PD, pin);
    }
    else if (mode == INPUT_PULLUP)
    {
        GPIO_RegOneBitSet(GPIO_B_IE, pin);
        GPIO_RegOneBitClear(GPIO_B_OE, pin);
		GPIO_RegOneBitClear(GPIO_B_PU, pin);//b'00 = pull up
	    GPIO_RegOneBitClear(GPIO_B_PD, pin);
    }
    else if (mode == OUTPUT)
    {
        GPIO_RegOneBitSet(GPIO_B_OE, pin);
        GPIO_RegOneBitClear(GPIO_B_IE, pin);
		GPIO_RegOneBitSet(GPIO_B_PU, pin);//b'10 = no pull-up, no pull-down
	    GPIO_RegOneBitClear(GPIO_B_PD, pin);
    }
	
}

void digitalWrite( int pin_m, uint8_t value )
{
    uint32_t pin = pin_dmux[pin_m];

	if(value & 0x01)
	{
		GPIO_RegOneBitSet(GPIO_B_OUT, pin);
	}
	else
	{
		GPIO_RegOneBitClear(GPIO_B_OUT, pin);
	}	
}

int digitalRead( int pin_m )
{
    uint32_t pin = pin_dmux[pin_m];
    return GPIO_RegOneBitGet(GPIO_B_IN, pin);
}


