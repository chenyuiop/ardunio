/*
  HardwareSerial.cpp - Hardware serial library for Wiring
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Modified 23 November 2006 by David A. Mellis
  Modified 28 September 2010 by Mark Sproul
  Modified 14 August 2012 by Alarus
  Modified 3 December 2013 by Matthijs Kooijman
*/
#include "Arduino.h"
#include "uarts_interface.h"
HardwareSerial::HardwareSerial(int pUartConsole) {
	UartConsole = pUartConsole;
}

void HardwareSerial::begin(uint32_t baud)
{
	begin(baud, SERIAL_8N1);
}

void HardwareSerial::begin(uint32_t baud,uint32_t config)
{
	u8 UART_DRV_DATABITS = (u8) ((config >> 8) & 0xf);
	u8 UART_DRV_STOPBITS = (u8) (config & 0xf);
	u8 UART_DRV_PARITY = (u8) ((config >> 4) & 0xf);
	//UART_DATA_t tUartData ={baud, UART_DRV_DATABITS,UART_DRV_STOPBITS,UART_DRV_PARITY};
	//UART_Init(UartConsole,&tUartData);
	//UART_IsrInit(UartConsole);
	
	GPIO_UartTxIoConfig(UartConsole, 1);//C2
	GPIO_UartRxIoConfig(UartConsole, 1);//C3
	UARTS_Init(0, baud, UART_DRV_DATABITS, UART_DRV_PARITY, UART_DRV_STOPBITS);
	//UARTS_Init(UartConsole, baud, 8, 0, 1);

	//UART0_Send((uint8_t*)"HardwareSerial::begin\n  ",sizeof("HardwareSerial::begin\n  "));

}

void HardwareSerial::end()
{
	//UART_DeInit(UartConsole);
}

int HardwareSerial::available(void)
{
	
  return !UARTS_IOCTL(UartConsole,UART_IOCTL_RX_FIFO_EMPTY,0);// uartDataCheck(UartConsole);
}

int HardwareSerial::read(void)
{
	u8 val = 0;
		
	//if(available())
	if(!UARTS_IOCTL(UartConsole,UART_IOCTL_RX_FIFO_EMPTY,0))
	{
		if(UARTS_Recv(UartConsole,&val,1))
		{
			return val;//uartReadByte(UartConsole);
		}		
	}
		
	return -1;
}

size_t HardwareSerial::write(uint8_t c)
{

	//UARTS_SendByte(UartConsole,c);
	//printf(" HardwareSerial::write\n");
	return 1;
}

int HardwareSerial::peek(void)
{
//	if(available())
//		return 0;//uartPeekByte(UartConsole);
	return -1;
}
void HardwareSerial::flush()
{
	//uartFlush(UartConsole);
}
